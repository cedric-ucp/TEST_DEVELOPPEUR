import { Component, OnInit, } from '@angular/core';
import { HttpClient } from '@angular/common/http'

export class Projects{
  constructor(
    public id : number,
    public Image : string,
    public Title : string,
    public Introduction : string,
    public LastMod : string,
    public IdTheme : number,
    public categorie : string

  ){ 

  }
}

@Component({
  selector: 'app-projects',
  templateUrl : './projects.component.html',
  styleUrls: ['./projects.component.css']
})

export class ProjectsComponent implements OnInit {

  projects: Projects [] = []
  constructor (private httpClient : HttpClient ) {}

  ngOnInit(): void {
    this.httpClient.get <Projects []> ('http://localhost/api').subscribe ((response) =>{
    this.projects = response
    })
  }


}
