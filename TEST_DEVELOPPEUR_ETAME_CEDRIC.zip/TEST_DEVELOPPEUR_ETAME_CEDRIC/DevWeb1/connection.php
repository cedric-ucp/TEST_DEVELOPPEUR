<?php
 $dbhost = "localhost";
 $dbuser = "root";
 $dbpass = "";
 $db = "kainsensdata";
 $con = mysqli_connect($dbhost, $dbuser, $dbpass , $db) or die($con);
?>